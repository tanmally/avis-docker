#!/bi/bash
INSTANCE_ID=$(basename $(pwd))
PID_FILE=pid
LOG_FILE=log
