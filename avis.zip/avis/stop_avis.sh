#!/bin/bash

. ./setenv.sh

if [ -a $PID_FILE ]; then
	echo "STOPPING instance $INSTANCE_ID"
	kill `cat $PID_FILE`
	rm $PID_FILE
else
	echo "AVIS $INSTANCE_ID not running..."
fi
