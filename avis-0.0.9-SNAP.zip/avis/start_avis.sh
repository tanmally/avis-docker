#!/bin/bash

. ./setenv.sh

if [ -a $PID_FILE ]; then
	echo "INSTANCE $INSTANCE_ID IS ALREADY RUNNING."
else
	echo "STARTING INSTANCE $INSTANCE_ID"
	java -cp .:lib/*:/opt/bbytes/avis_conf:avis-server-0.0.8-SNAPSHOT.jar com.bbytes.avis.Main
	echo "$!" > $PID_FILE
fi
